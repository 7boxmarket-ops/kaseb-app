from pathlib import Path
from PIL import Image
ROOT = Path("android/app/src/main/res")
SRC = Image.open("assets/kaseb-app-icon.png").convert("RGBA")
def make_icon(size, adaptive=False):
    canvas = Image.new("RGBA", (size, size), (255,112,0,255))
    side = int(size * (0.68 if adaptive else 0.88))
    img = SRC.copy(); img.thumbnail((side, side), Image.Resampling.LANCZOS)
    canvas.alpha_composite(img, ((size-img.width)//2, (size-img.height)//2))
    return canvas
for folder, size in [("mipmap-mdpi",48),("mipmap-hdpi",72),("mipmap-xhdpi",96),("mipmap-xxhdpi",144),("mipmap-xxxhdpi",192)]:
    out=ROOT/folder; out.mkdir(parents=True,exist_ok=True)
    icon=make_icon(size); icon.save(out/"ic_launcher.png",optimize=True); icon.save(out/"ic_launcher_round.png",optimize=True)
fg=ROOT/"drawable-nodpi"; fg.mkdir(parents=True,exist_ok=True); make_icon(432,True).save(fg/"ic_launcher_foreground.png",optimize=True)
anydpi=ROOT/"mipmap-anydpi-v26"; anydpi.mkdir(parents=True,exist_ok=True)
xml='''<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
 <background android:drawable="@color/ic_launcher_background" />
 <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
'''
for name in ("ic_launcher.xml","ic_launcher_round.xml"): (anydpi/name).write_text(xml,encoding="utf-8")
colors=ROOT/"values"; colors.mkdir(parents=True,exist_ok=True)
(colors/"ic_launcher_background.xml").write_text('<resources><color name="ic_launcher_background">#FF7000</color></resources>\n',encoding="utf-8")
print("Custom Kaseb launcher icons generated.")
