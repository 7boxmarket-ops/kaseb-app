import { Capacitor } from '@capacitor/core';
import { SpeechRecognition } from '@capacitor-community/speech-recognition';

window.KasebNativeSpeech = {
  isNative() {
    try { return !!(Capacitor && Capacitor.isNativePlatform()); }
    catch (_) { return false; }
  },
  async listen() {
    const available = await SpeechRecognition.available();
    if (!available || !available.available) {
      throw new Error('Speech recognition is not available on this device.');
    }
    let permissions = await SpeechRecognition.checkPermissions();
    if (!permissions || permissions.speechRecognition !== 'granted') {
      permissions = await SpeechRecognition.requestPermissions();
    }
    if (!permissions || permissions.speechRecognition !== 'granted') {
      throw new Error('Microphone permission denied.');
    }
    const result = await SpeechRecognition.start({
      language: 'fa-IR',
      maxResults: 5,
      prompt: 'برای ثبت فرمان یا فاکتور صحبت کنید',
      partialResults: false,
      popup: true
    });
    const matches = result && Array.isArray(result.matches) ? result.matches : [];
    return matches.length ? matches[0] : '';
  }
};
