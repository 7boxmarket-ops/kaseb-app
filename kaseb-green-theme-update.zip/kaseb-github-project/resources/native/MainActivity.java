package com.sevenbox.kaseb;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.getcapacitor.BridgeActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * Kaseb native bridge and Android back-button integration.
 */
public class MainActivity extends BridgeActivity {

    private WebView printView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().addJavascriptInterface(new KasebBridge(), "KasebNative");
        }
        // Match the Android system status bar to the app surface from first launch.
        getWindow().setStatusBarColor(Color.rgb(243, 251, 246));
        if (Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }

    /**
     * Forward Android Back to the existing Kaseb web-app navigation.
     * The web app prevents the synthetic Escape event when it handled the back action.
     * If no page/modal handled it (for example, on the home screen), Android's normal
     * back behavior is preserved and the Activity can close normally.
     */
    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (getBridge() == null || getBridge().getWebView() == null) {
            super.onBackPressed();
            return;
        }

        final WebView webView = getBridge().getWebView();
        webView.evaluateJavascript(
                "(function(){"
                        + "var event = new KeyboardEvent('keydown', {"
                        + "key: 'Escape', bubbles: true, cancelable: true"
                        + "});"
                        + "return !document.dispatchEvent(event);"
                        + "})()",
                new android.webkit.ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String handled) {
                        if (!"true".equals(handled)) {
                            MainActivity.super.onBackPressed();
                        }
                    }
                }
        );
    }

    public class KasebBridge {

        @JavascriptInterface
        public void setStatusBarColor(final String color, final boolean darkTheme) {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        if (color == null || !color.matches("#[0-9A-Fa-f]{6}")) return;
                        Window window = MainActivity.this.getWindow();
                        window.setStatusBarColor(Color.parseColor(color));
                        if (Build.VERSION.SDK_INT >= 23) {
                            int flags = window.getDecorView().getSystemUiVisibility();
                            if (darkTheme) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                            else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                            window.getDecorView().setSystemUiVisibility(flags);
                        }
                    } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface
        public void printHtml(final String html, final String title) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        WebView wv = new WebView(MainActivity.this);
                        printView = wv;
                        wv.setWebViewClient(new WebViewClient() {
                            @Override
                            public void onPageFinished(WebView view, String url) {
                                PrintManager pm = (PrintManager) MainActivity.this.getSystemService(Context.PRINT_SERVICE);
                                PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(title);
                                pm.print(title, adapter, new PrintAttributes.Builder()
                                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                        .build());
                            }
                        });
                        wv.loadDataWithBaseURL("https://localhost/", html, "text/html", "UTF-8", null);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public String saveFile(String name, String mime, String content) {
            try {
                byte[] data = content.getBytes("UTF-8");
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) return "error:insert";
                    OutputStream os = getContentResolver().openOutputStream(uri);
                    if (os == null) return "error:stream";
                    os.write(data);
                    os.close();
                    return "ok:Download";
                } else {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    if (dir != null && !dir.exists()) dir.mkdirs();
                    File f = new File(dir, name);
                    FileOutputStream os = new FileOutputStream(f);
                    os.write(data);
                    os.close();
                    return "ok:" + f.getAbsolutePath();
                }
            } catch (Exception e) {
                return "error:" + e.getMessage();
            }
        }
    }
}
