# کاسب | Kaseb Android Release

## نام مخزن
`kaseb-app`

## ساخت APK با GitHub Actions
1. محتویات این ZIP را در ریشه مخزن GitHub با نام `kaseb-app` آپلود کنید؛ پوشه `.github/workflows` باید حفظ شود.
2. مخزن باید برای این روش ساده Public باشد؛ اگر Private است، نیازی به عمومی کردن برای GitHub Actions نیست، اما Worker عمومی فایل را از آن دریافت نمی‌کند.
3. در Settings → Secrets and variables → Actions این چهار Secret را اضافه کنید:
   - `KEYSTORE_BASE64`
   - `KEYSTORE_PASSWORD`
   - `KEY_ALIAS` (مقدار: `kaseb-release`)
   - `KEY_PASSWORD`
4. در Actions، گردش‌کار `Build Android Release APK` را باز کنید و Run workflow بزنید.
5. بعد از موفقیت، فایل `kaseb-android-release` را از بخش Artifacts دانلود کنید.
6. برای پیوست APK به GitHub Release، تگ `v1.0.0` را بسازید و push کنید.

## استخراج ZIP خودکار
فایل `source/kaseb-source.zip` در زمان اجرای workflow به‌صورت خودکار استخراج می‌شود و `index.html` برنامه را آماده می‌کند.

## امضای APK
کلید JKS، رمزها و فایل Base64 آن را هرگز در مخزن GitHub قرار ندهید؛ فقط از GitHub Actions Secrets استفاده کنید. کلید امضا را در جای امن پشتیبان‌گیری کنید.

## Cloudflare Worker
فایل `worker/worker.js` فقط نسخه وب را نمایش می‌دهد. استخراج ZIP و ساخت APK توسط GitHub Actions انجام می‌شود، نه Worker.
