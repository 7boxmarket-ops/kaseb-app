#!/usr/bin/env bash
set -euo pipefail
mkdir -p android/app/src/main/res
cp -R android-icons/res/. android/app/src/main/res/
echo "Kaseb launcher icons copied into Android resources."
