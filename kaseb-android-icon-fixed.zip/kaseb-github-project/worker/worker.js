// Cloudflare Worker name: kaseb-web
// Purpose: serve the current Kaseb web app from the public GitHub repository.
// Replace OWNER/REPO if you use a different repository name.
const SOURCE_URL = 'https://raw.githubusercontent.com/7boxmarket-ops/kaseb-app/main/index.html';

export default {
  async fetch(request) {
    const url = new URL(request.url);

    if (request.method !== 'GET' && request.method !== 'HEAD') {
      return new Response('Method Not Allowed', { status: 405, headers: { 'Allow': 'GET, HEAD' } });
    }

    if (url.pathname === '/health') {
      return new Response('kaseb-web: ok', {
        headers: { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' }
      });
    }

    try {
      const upstream = await fetch(SOURCE_URL, {
        headers: { 'Accept': 'text/html' },
        cf: { cacheTtl: 60, cacheEverything: true }
      });

      if (!upstream.ok) {
        return new Response('Kaseb source could not be loaded. Check SOURCE_URL and repository visibility.', {
          status: 502,
          headers: { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' }
        });
      }

      const headers = new Headers(upstream.headers);
      headers.set('content-type', 'text/html; charset=utf-8');
      headers.set('x-content-type-options', 'nosniff');
      headers.set('referrer-policy', 'strict-origin-when-cross-origin');
      headers.set('cache-control', 'public, max-age=60');
      return new Response(request.method === 'HEAD' ? null : await upstream.text(), {
        status: 200,
        headers
      });
    } catch (error) {
      return new Response('Kaseb Worker error.', {
        status: 502,
        headers: { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' }
      });
    }
  }
};
