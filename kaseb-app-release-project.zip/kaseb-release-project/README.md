# کاسب | Kaseb Android Release

این مخزن، نسخه وب برنامه کاسب و گردش‌کار ساخت APK اندروید Release را دارد.

## نام‌های پیشنهادی
- GitHub repository: `kaseb-app`
- Cloudflare Worker: `kaseb-web`
- Android application ID: `com.sevenbox.kaseb`
- نمایش برنامه: `کاسب`

## ساخت APK امضاشده
1. یک keystore شخصی بسازید و نسخه پشتیبان امن آن را نگه دارید.
2. در GitHub وارد Settings → Secrets and variables → Actions شوید و این Secrets را بسازید:
   - `KEYSTORE_BASE64`
   - `KEYSTORE_PASSWORD`
   - `KEY_ALIAS`
   - `KEY_PASSWORD`
3. فایل‌های این پروژه را در مخزن `kaseb-app` قرار دهید.
4. از Actions، گردش‌کار **Build Android Release APK** را با **Run workflow** اجرا کنید.
5. در پایان، از صفحه اجرای workflow بخش **Artifacts** فایل `kaseb-android-release` را دریافت کنید.
6. برای ساخت GitHub Release، یک tag با نامی مثل `v1.0.0` ایجاد و push کنید. APK به Release همان tag پیوست می‌شود.

## Cloudflare Worker
فایل `worker/worker.js` یک Worker ساده برای نمایش نسخه HTML از GitHub است. قبل از Deploy، مقدار `OWNER` در `SOURCE_URL` را با نام کاربری/سازمان GitHub خود جایگزین کنید. مخزن باید Public باشد؛ در غیر این صورت باید از روش احراز هویت امن دیگری استفاده شود. این Worker APK نمی‌سازد؛ ساخت APK توسط GitHub Actions انجام می‌شود.
